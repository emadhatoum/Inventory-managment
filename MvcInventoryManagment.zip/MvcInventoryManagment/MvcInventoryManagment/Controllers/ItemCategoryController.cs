﻿using Microsoft.AspNetCore.Mvc;
using MvcInventoryManagment.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using InventoryManagment.EF.Context;
using InventoryManagment.EF.Models;

namespace MvcInventoryManagment.Controllers
{
    public class ItemCategoryController : Controller
    {
        private readonly InventoryManagmentContext _context;

        public ItemCategoryController(InventoryManagmentContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            ItemCategoryViewModel model = new ItemCategoryViewModel(_context);
            return View(model);
        }

        [HttpPost]
        //the comand below from Banking.cs
        public IActionResult Index(int categoryId, string category, string description, int storeId)
        {
            ItemCategoryViewModel model = new ItemCategoryViewModel(_context);

            ItemCategory account = new ItemCategory (categoryId, category, description, storeId);

            model.SaveAccount(account);
            model.IsActionSuccess = true;
            model.ActionMessage = "Account has been saved successfully";

            return View(model);
        }

        public IActionResult Update(int id)
        {
            ItemCategoryViewModel model = new ItemCategoryViewModel(_context, id);
            return View(model);
        }

        public IActionResult Delete(int id)
        {
            ItemCategoryViewModel model = new ItemCategoryViewModel(_context);

            if (id > 0)
            {
                model.RemoveItemCategory(id);
            }

            model.IsActionSuccess = true;
            model.ActionMessage = "Account has been deleted successfully";
            return View("Index", model);
        }
    }
}
