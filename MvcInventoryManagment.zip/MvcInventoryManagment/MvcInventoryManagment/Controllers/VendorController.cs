﻿using Microsoft.AspNetCore.Mvc;
using MvcInventoryManagment.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using InventoryManagment.EF.Context;
using InventoryManagment.EF.Models;

namespace MvcInventoryManagment.Controllers
{
    public class VendorController : Controller
    {
        private readonly InventoryManagmentContext _context;

        public VendorController(InventoryManagmentContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            VendorViewModel model = new VendorViewModel(_context);
            return View(model);
        }

        [HttpPost]
        //the comand below from Banking.cs
        public IActionResult Index(int vendorId, string vendorName, string address, int phoneNumber, string emailAddress, string contactName)
        {
            VendorViewModel model = new VendorViewModel(_context);

            Vendor vendor = new Vendor(vendorId, vendorName, address, phoneNumber, emailAddress, contactName);

            model.SaveAccount(vendor);
            model.IsActionSuccess = true;
            model.ActionMessage = "Account has been saved successfully";

            return View(model);
        }

        public IActionResult Update(int Id)
        {
            VendorViewModel model = new VendorViewModel(_context, Id);
            return View(model);
        }

        public IActionResult Delete(int Id)
        {
            VendorViewModel model = new VendorViewModel(_context);

            if (Id > 0)
            {
                model.RemoveAccount(Id);
            }

            model.IsActionSuccess = true;
            model.ActionMessage = "Account has been deleted successfully";
            return View("Index", model);
        }
    }
}