﻿using Microsoft.AspNetCore.Mvc;
using MvcInventoryManagment.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using InventoryManagment.EF.Context;
using InventoryManagment.EF.Models;
using Microsoft.EntityFrameworkCore;


namespace MVCContactsApp.Controllers
{
    public class ItemController : Controller
    {
        private readonly InventoryManagmentContext _context;

        public ItemController(InventoryManagmentContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            ItemViewModel model = new ItemViewModel(_context);
            return View(model);
        }

        [HttpPost]
        //the comand below from Banking.cs
        public IActionResult Index(int itemId, string itemNumber, string itemCategory, string vendor, int quantityOnHand, DateTime purchaseDate, string brand, string itemDetail, decimal unitprice, decimal itemCost, int storeId)
        {
            ItemViewModel model = new ItemViewModel(_context);

            Item account = new Item( itemId,  itemNumber, itemCategory, vendor,  quantityOnHand,  purchaseDate, brand,  itemDetail, unitprice,  itemCost,  storeId);

            model.SaveAccount(account);
            model.IsActionSuccess = true;
            model.ActionMessage = "Account has been saved successfully";

            return View(model);
        }

        public IActionResult Update(int id)
        {
            ItemViewModel model = new ItemViewModel(_context,id);
            return View(model);
        }

        public IActionResult Delete(int id)
        {
            ItemViewModel model = new ItemViewModel(_context);

            if (id > 0)
            {
                model.RemoveAccount(id);
            }

            model.IsActionSuccess = true;
            model.ActionMessage = "Account has been deleted successfully";
            return View("Index", model);
        }
     }

}

