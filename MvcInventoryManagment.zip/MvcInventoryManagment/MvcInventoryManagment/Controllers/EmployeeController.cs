﻿using Microsoft.AspNetCore.Mvc;
using MvcInventoryManagment.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using InventoryManagment.EF.Context;
using InventoryManagment.EF.Models;

namespace InventoryManagment.Controllers
{
    public class EmployeeController : Controller
    {
        private readonly InventoryManagmentContext _context;

        public EmployeeController(InventoryManagmentContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            EmployeeViewModel model = new EmployeeViewModel(_context);
            return View(model);
        }

        [HttpPost]
        //the comand below from Banking.cs
        public IActionResult Index(int Ssn, string firstName, string lastName, string address, string dob, string maritalStatus, int numberOfKids, string phoneNumber, string emailAddress,int id, string apt, string city, string state, int zip)
        {
            EmployeeViewModel model = new EmployeeViewModel(_context);
            // the information bellow will be used in update.cshtml so the parameter should mach
            Employee employee = new Employee( Ssn, firstName,  lastName,  address,  dob,  maritalStatus,   numberOfKids,  phoneNumber,  emailAddress,  id,  apt,  city,  state,  zip);
            
            model.SaveAccount(employee);
            model.IsActionSuccess = true;
            model.ActionMessage = "Employee has been saved successfully";

            return View(model);
        }

        public IActionResult Update(int id)
        {
            EmployeeViewModel model = new EmployeeViewModel(_context, id);
            return View(model);
        }

        public IActionResult Delete(int id)
        {
            EmployeeViewModel model = new EmployeeViewModel(_context);

            if (id > 0)
            {
                model.RemoveAccount(id);
            }

            model.IsActionSuccess = true;
            model.ActionMessage = "Employee has been deleted successfully";
            return View("Index", model);
        }
    }
}