﻿using Microsoft.AspNetCore.Mvc;
using MvcInventoryManagment.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using InventoryManagment.EF.Context;
using InventoryManagment.EF.Models;

namespace  MvcInventoryManagment .Controllers

{
    public class BrandController : Controller
    {
        private readonly InventoryManagmentContext _context;

        public BrandController(InventoryManagmentContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            BrandViewModel model = new BrandViewModel(_context);
            return View(model);
        }

        [HttpPost]
        //the comand below from brand.cs
        public IActionResult Index(int brandId, string name)
        {
            BrandViewModel model = new BrandViewModel (_context);

            Brand brand = new Brand(brandId, name);

            model.SaveAccount(brand);
            model.IsActionSuccess = true;
            model.ActionMessage = "Account has been saved successfully";

            return View(model);
        }

        public IActionResult Update(int id)
        {
         BrandViewModel model = new BrandViewModel(_context, id);
            return View(model);
        }

        public IActionResult Delete(int id)
        {
            BrandViewModel model = new BrandViewModel(_context);

            if (id > 0)
            {
                model.RemoveBrand(id);
            }

            model.IsActionSuccess = true;
            model.ActionMessage = "Brand has been deleted successfully";
            return View("Index", model);
        }
    }
}