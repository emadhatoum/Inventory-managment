﻿using Microsoft.AspNetCore.Mvc;
using MvcInventoryManagment.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using InventoryManagment.EF.Context;
using InventoryManagment.EF.Models;

namespace MvcInventoryManagment.Controllers
{
    public class CustomerController : Controller
    {
        private readonly InventoryManagmentContext _context;

        public CustomerController(InventoryManagmentContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            CustomerViewModel model = new CustomerViewModel(_context);
            return View(model);
        }

        [HttpPost]
        //the comand below from Banking.cs
        public IActionResult Index(string name, int customerPhoneNumber, string address, string emailAddress,int CustomerId,string apt,string city,string state,int zip)
        {
            CustomerViewModel model = new CustomerViewModel(_context);

            Customer customer = new Customer(name, customerPhoneNumber, address, emailAddress, CustomerId , apt,  city,  state,  zip);

            model.SaveAccount(customer);
            model.IsActionSuccess = true;
            model.ActionMessage = "Customer has been saved successfully";

            return View(model);
        }

        public IActionResult Update(int id)
        {
            CustomerViewModel model = new CustomerViewModel(_context, id);
            return View(model);
        }

        public IActionResult Delete(int id)
        {
            CustomerViewModel model = new CustomerViewModel(_context);

            if (id > 0)
            {
                model.RemoveCustomer(id);
            }

            model.IsActionSuccess = true;
            model.ActionMessage = "Customer has been deleted successfully";
            return View("Index", model);
        }
    }
}