﻿using Microsoft.AspNetCore.Mvc;
using MvcInventoryManagment.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using InventoryManagment.EF.Context;
using InventoryManagment.EF.Models;

namespace MvcInventoryManagment.Controllers
{
    public class SalesController : Controller
    {
        private readonly InventoryManagmentContext _context;

        public SalesController(InventoryManagmentContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            SalesViewModel model = new SalesViewModel(_context);
            return View(model);
        }

        [HttpPost]
        //the comand below from Banking.cs
        public IActionResult Index(int invoiceNumber, int itemNumber, string itemDetails, int quantity, decimal unitPrice, decimal salesTax, decimal totalPrice, string customerPhoneNumber)
        {
            SalesViewModel model = new SalesViewModel(_context);

            Sales account = new Sales( invoiceNumber,  itemNumber,  itemDetails,  quantity,  unitPrice,  salesTax,  totalPrice,  customerPhoneNumber);

            model.SaveAccount(account);
            model.IsActionSuccess = true;
            model.ActionMessage = "Account has been saved successfully";

            return View(model);
        }

        public IActionResult Update(int id)
        {
            SalesViewModel model = new SalesViewModel(_context, id);
            return View(model);
        }

        public IActionResult Delete(int id)
        {
            SalesViewModel model = new SalesViewModel(_context);

            if (id > 0)
            {
                model.RemoveAccount(id);
            }

            model.IsActionSuccess = true;
            model.ActionMessage = "Account has been deleted successfully";
            return View("Index", model);
        }
    }
}