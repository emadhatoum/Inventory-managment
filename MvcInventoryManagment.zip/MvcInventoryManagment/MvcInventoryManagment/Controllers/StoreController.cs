﻿using Microsoft.AspNetCore.Mvc;
using MvcInventoryManagment.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using InventoryManagment.EF.Context;
using InventoryManagment.EF.Models;

namespace MVCContactsApp.Controllers
{
    public class StoreController : Controller
    {
        private readonly InventoryManagmentContext _context;

        public StoreController(InventoryManagmentContext context)
        {
            _context = context;
        }

        public IActionResult Index()
        {
            StoreViewModel model = new StoreViewModel(_context);
            return View(model);
        }

        [HttpPost]
        //the comand below from Banking.cs
        public IActionResult Index(string storeName, int phoneNumber, string emailAddress, string address, string contactName, string userName)
        {
            StoreViewModel model = new StoreViewModel(_context);

            Store account = new Store( storeName,  phoneNumber,  emailAddress,  address,  contactName,  userName);

            model.SaveAccount(account);
            model.IsActionSuccess = true;
            model.ActionMessage = "Account has been saved successfully";

            return View(model);
        }

        public IActionResult Update(int id)
        {
            StoreViewModel model = new StoreViewModel(_context, id);
            return View(model);
        }

        public IActionResult Delete(int id)
        {
            StoreViewModel model = new StoreViewModel(_context);

            if (id > 0)
            {
                model.RemoveAccount(id);
            }

            model.IsActionSuccess = true;
            model.ActionMessage = "Account has been deleted successfully";
            return View("Index", model);
        }
    }
}
