﻿using InventoryManagment.EF.Context;
using InventoryManagment.EF.Repositories;
using InventoryManagment.EF.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MvcInventoryManagment.Models
{
    public class CustomerViewModel
    {
        private CustomerRepositories _repo;

        public List<Customer> CustomerList { get; set; }

        public Customer CurrentCustomer { get; set; }

        public bool IsActionSuccess { get; set; }

        public string ActionMessage { get; set; }

        public CustomerViewModel(InventoryManagmentContext context)
        {
            _repo = new CustomerRepositories(context);
            CustomerList = GetAllCustomers();
            CurrentCustomer = CustomerList.FirstOrDefault();
        }

        public CustomerViewModel(InventoryManagmentContext context, int customerId)
        {
            _repo = new CustomerRepositories(context);
            CustomerList = GetAllCustomers();

            if (customerId > 0)
            {
                CurrentCustomer = GetCustomer(customerId);
            }
            else
            {
                CurrentCustomer = new Customer();
            }
        }

        public void SaveAccount(Customer customer)
        {
            if (customer.CustomerId > 0)
            {
                _repo.Update(customer);
            }
            else
            {
                customer.CustomerId = _repo.Create(customer);
            }

            CustomerList = GetAllCustomers();
            CurrentCustomer = GetCustomer(customer.CustomerId);
        }

        public void RemoveCustomer(int customerID)
        {
            _repo.Delete(customerID);
            CustomerList = GetAllCustomers();
            CurrentCustomer = CustomerList.FirstOrDefault();
        }

        public List<Customer> GetAllCustomers()
        {
            return _repo.GetAllCustomers();
        }

        public Customer GetCustomer(int customerId)
        {
            return _repo.GetCustomertByID(customerId);
        }
    }
}


