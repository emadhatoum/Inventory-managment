﻿using InventoryManagment.EF.Context;
using InventoryManagment.EF.Repositories;
using InventoryManagment.EF.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MvcInventoryManagment.Models
{
    public class ItemCategoryViewModel
    {
        private ItemCategoryRepositories _repo;

        public List<ItemCategory> ItemCategoryList { get; set; }

        public ItemCategory CurrentItemCategory { get; set; }

        public bool IsActionSuccess { get; set; }

        public string ActionMessage { get; set; }

        public ItemCategoryViewModel(InventoryManagmentContext context)
        {
            _repo = new ItemCategoryRepositories(context);
            ItemCategoryList = GetAllItemCategory();
            CurrentItemCategory = ItemCategoryList.FirstOrDefault();
        }

        public ItemCategoryViewModel(InventoryManagmentContext context, int itemCategoryId)
        {
            _repo = new ItemCategoryRepositories(context);
            ItemCategoryList = GetAllItemCategory();

            if (itemCategoryId > 0)
            {
                CurrentItemCategory = GetItemCategory(itemCategoryId);
            }
            else
            {
                CurrentItemCategory = new ItemCategory();
            }
        }

        public void SaveAccount(ItemCategory categoryId)
        {
            if (categoryId.CategoryId > 0)
            {
                _repo.Update(categoryId);
            }
            else
            {
                categoryId.CategoryId = _repo.Create(categoryId);
            }

            ItemCategoryList = GetAllItemCategory();
            CurrentItemCategory = GetItemCategory(categoryId.CategoryId);
        }

        public void RemoveItemCategory(int categoryId)
        {
            _repo.Delete(categoryId);
            ItemCategoryList = GetAllItemCategory();
            CurrentItemCategory = ItemCategoryList.FirstOrDefault();
        }

        public List<ItemCategory> GetAllItemCategory()
        {
            return _repo.GetAllItemCategory();
        }

        public ItemCategory GetItemCategory(int categoryId)
        {
            return _repo.GetItemCategoryByID(categoryId);
        }
    }
}
