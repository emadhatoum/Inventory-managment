﻿using InventoryManagment.EF.Context;
using InventoryManagment.EF.Repositories;
using InventoryManagment.EF.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MvcInventoryManagment.Models
{
    public class SalesViewModel
    {
        private SalesRepositories _repo;

        public List<Sales> SalesList { get; set; }

        public Sales CurrentSales { get; set; }

        public bool IsActionSuccess { get; set; }

        public string ActionMessage { get; set; }

        public SalesViewModel(InventoryManagmentContext context)
        {
            _repo = new SalesRepositories(context);
            SalesList = GetAllSales();
            CurrentSales = SalesList.FirstOrDefault();
        }

        public SalesViewModel(InventoryManagmentContext context, int accountId)
        {
            _repo = new SalesRepositories(context);
            SalesList = GetAllSales();

            if (accountId > 0)
            {
                CurrentSales = GetSales(accountId);
            }
            else
            {
                CurrentSales = new Sales();
            }
        }

        public void SaveAccount(Sales account)
        {
            if (account.InvoiceNumber > 0)
            {
                _repo.Update(account);
            }
            else
            {
                account.InvoiceNumber = _repo.Create(account);
            }

            SalesList = GetAllSales();
            CurrentSales = GetSales(account.InvoiceNumber);
        }

        public void RemoveAccount(int accountID)
        {
            _repo.Delete(accountID);
            SalesList = GetAllSales();
            CurrentSales = SalesList.FirstOrDefault();
        }

        public List<Sales> GetAllSales()
        {
            return _repo.GetAllSales();
        }

        public Sales GetSales(int accountId)
        {
            return _repo.GetSalesByID(accountId);
        }
    }
}

