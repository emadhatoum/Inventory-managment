﻿using InventoryManagment.EF.Context;
using InventoryManagment.EF.Repositories;
using InventoryManagment.EF.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MvcInventoryManagment.Models
{
    public class BrandViewModel
    {
        private BrandRepositories _repo;

        public List<Brand> BrandList { get; set; }

        public Brand CurrentBrand { get; set; }

        public bool IsActionSuccess { get; set; }

        public string ActionMessage { get; set; }

        public BrandViewModel(InventoryManagmentContext context)
        {
            _repo = new BrandRepositories(context);
            BrandList = GetAllBrands();
            CurrentBrand = BrandList.FirstOrDefault();
        }

        public BrandViewModel(InventoryManagmentContext context, int brandId)
        {
            _repo = new BrandRepositories(context);
            BrandList = GetAllBrands();

            if (brandId > 0)
            {
                CurrentBrand = GetBrand(brandId);
            }
            else
            {
                CurrentBrand = new Brand();
            }
        }

        public void SaveAccount(Brand brand)
        {
            if (brand.BrandId > 0)
            {
                _repo.Update(brand);
            }
            else
            {
                brand.BrandId = _repo.Create(brand);
            }

            BrandList = GetAllBrands();
            CurrentBrand = GetBrand(brand.BrandId);
        }

        public void RemoveBrand(int brandId)
        {
            _repo.Delete(brandId);
            BrandList = GetAllBrands();
            CurrentBrand = BrandList.FirstOrDefault();
        }

        public List<Brand> GetAllBrands()
        {
            return _repo.GetAllBrands();
        }

        public Brand GetBrand(int accountId)
        {
            return _repo.GetBrandByID(accountId);
        }
    }
}

