﻿using InventoryManagment.EF.Context;
using InventoryManagment.EF.Repositories;
using InventoryManagment.EF.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using System.Web;


namespace MvcInventoryManagment.Models
{
    public class ItemViewModel:Vendor
    {
        private ItemRepositories _repo;
        
        public List<Vendor> vendor { get; set; }
        public List<Item> ItemList { get; set; }
        public List<string> SearchTerms { get; set; }

        public Item CurrentItem { get; set; }

        public bool IsActionSuccess { get; set; }

        public string ActionMessage { get; set; }
        

        public ItemViewModel(InventoryManagmentContext context)
        {
            _repo = new ItemRepositories(context);
            ItemList = GetAllItems();
            CurrentItem = ItemList.FirstOrDefault();
            SearchTerms = GetSearchCategories();
        }

        public ItemViewModel(InventoryManagmentContext context, int itemId)
        {
            _repo = new ItemRepositories(context);
            SearchTerms = GetSearchCategories();
            ItemList = GetAllItems();

            if (itemId > 0)
            {
                CurrentItem = GetItem(itemId);
            }
            else
            {
                CurrentItem = new Item();
            }
        }

        public void SaveAccount(Item item)
        {
            if (item.ItemId > 0)
            {
                _repo.Update(item);
            }
            else
            {
                item.ItemId = _repo.Create(item);
            }

            ItemList = GetAllItems();
            CurrentItem = GetItem(item.ItemId);
        }

        public void RemoveAccount(int itemId)
        {
            _repo.Delete(itemId);
            ItemList = GetAllItems();
            CurrentItem = ItemList.FirstOrDefault();
        }

        public List<Item> GetAllItems()
        {
            return _repo.GetAllItems();
        }
        public List<string> GetSearchCategories()
        {
            List<string> searchBy = new List<string>();
            searchBy.Add("BRAND");
            searchBy.Add("VENDOR");
            searchBy.Add("ITEM CATEGORY");
            searchBy.Add("ITEM NUMBER");
            return searchBy;
        }
        //itemList.Vendor
       //{"Ali Baba", "Ali Baba", "Amazon", "Ali Baba"}
       //vendorNames
       //{"Ali Baba", "Amazon"}
        public List<string> VendorsList()
        {
            ItemList = GetAllItems();
            List<string> vendorNames = new List<string>();

            foreach(Item myItem in ItemList)
            {
                if(!vendorNames.Contains(myItem.Vendor))
                    vendorNames.Add(myItem.Vendor);
            }

            return vendorNames;
        }
        public List<Item> ItemsByVendor(string vendorName)
        {
            ItemList=GetAllItems();
            List<Item> itemsByVendor = new List<Item>();
            foreach(Item item in ItemList)
            {
                if(item.Vendor == vendorName)
                    itemsByVendor.Add(item);
            }
            return itemsByVendor;
        }



        //returning items
       
      




        /* public List<Item> listAll()
          {
              ItemList= GetAllItems();
          }*/

        public Item GetItem(int itemId)
        {
            return _repo.GetItemByID(itemId);
        }
    }   
}

