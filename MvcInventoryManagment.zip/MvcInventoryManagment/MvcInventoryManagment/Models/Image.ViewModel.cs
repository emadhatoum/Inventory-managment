﻿/*using InventoryManagment.EF.Context;
using InventoryManagment.EF.Repositories;
using InventoryManagment.EF.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MvcInventoryManagment.Models
{
    public class BankingViewModel
    {
        private BankingRepository _repo;

        public List<Banking> AccountList { get; set; }

        public Banking CurrentAccount { get; set; }

        public bool IsActionSuccess { get; set; }

        public string ActionMessage { get; set; }

        public BankingViewModel(SQLFundamentalsContext context)
        {
            _repo = new BankingRepository(context);
            AccountList = GetAllAccounts();
            CurrentAccount = AccountList.FirstOrDefault();
        }

        public BankingViewModel(SQLFundamentalsContext context, int accountId)
        {
            _repo = new BankingRepository(context);
            AccountList = GetAllAccounts();

            if (accountId > 0)
            {
                CurrentAccount = GetAccount(accountId);
            }
            else
            {
                CurrentAccount = new Banking();
            }
        }

        public void SaveAccount(Banking account)
        {
            if (account.AccountId > 0)
            {
                _repo.Update(account);
            }
            else
            {
                account.AccountId = _repo.Create(account);
            }

            AccountList = GetAllAccounts();
            CurrentAccount = GetAccount(account.AccountId);
        }

        public void RemoveAccount(int accountID)
        {
            _repo.Delete(accountID);
            AccountList = GetAllAccounts();
            CurrentAccount = AccountList.FirstOrDefault();
        }

        public List<Banking> GetAllAccounts()
        {
            return _repo.GetAllAccounts();
        }

        public Banking GetAccount(int accountId)
        {
            return _repo.GetAccountByID(accountId);
        }
    }
}

}*/
