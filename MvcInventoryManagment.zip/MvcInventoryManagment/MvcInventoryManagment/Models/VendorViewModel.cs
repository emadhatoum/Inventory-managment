﻿using InventoryManagment.EF.Context;
using InventoryManagment.EF.Repositories;
using InventoryManagment.EF.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MvcInventoryManagment.Models
{
    public class VendorViewModel
    {
        private VendorRepositories _repo;

        public List<Vendor> VendorList { get; set; }

        public Vendor CurrentVendor { get; set; }

        public bool IsActionSuccess { get; set; }

        public string ActionMessage { get; set; }

        public VendorViewModel(InventoryManagmentContext context)
        {
            _repo = new VendorRepositories(context);
            VendorList = GetAllVendors();
            CurrentVendor = VendorList.FirstOrDefault();
        }

        public VendorViewModel(InventoryManagmentContext context, int vendorId)
        {
            _repo = new VendorRepositories(context);
            VendorList = GetAllVendors();

            if (vendorId > 0)
            {
                CurrentVendor = GetVendor(vendorId);
            }
            else
            {
                CurrentVendor = new Vendor();
            }
        }

        public void SaveAccount(Vendor vendor)
        {
            if (vendor.VendorId > 0)
            {
                _repo.Update(vendor);
            }
            else
            {
                vendor.VendorId = _repo.Create(vendor);
            }

            VendorList = GetAllVendors();
            CurrentVendor = GetVendor(vendor.VendorId);
        }

        public void RemoveAccount(int vendorId)
        {
            _repo.Delete(vendorId);
            VendorList = GetAllVendors();
            CurrentVendor = VendorList.FirstOrDefault();
        }

        public List<Vendor> GetAllVendors()
        {
            return _repo.GetAllVendors();
        }

        public Vendor GetVendor(int vendorId)
        {
            return _repo.GetVendorByID(vendorId);
        }
    }
}

