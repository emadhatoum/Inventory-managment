﻿using InventoryManagment.EF.Context;
using InventoryManagment.EF.Repositories;
using InventoryManagment.EF.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MvcInventoryManagment.Models
{
    public class EmployeeViewModel
    {
        private EmployeeRepositories _repo;

        public List<Employee> EmployeeList { get; set; }

        public Employee CurrentEmployee { get; set; }

        public bool IsActionSuccess { get; set; }

        public string ActionMessage { get; set; }

        public EmployeeViewModel(InventoryManagmentContext context)
        {
            _repo = new EmployeeRepositories(context);
            EmployeeList = GetAllEmployee();
            CurrentEmployee = EmployeeList.FirstOrDefault();
        }

        public EmployeeViewModel(InventoryManagmentContext context, int employeeId)
        {
            _repo = new EmployeeRepositories(context);
            EmployeeList = GetAllEmployee();

            if (employeeId > 0)
            {
                CurrentEmployee = GetEmployee(employeeId);
            }
            else
            {
                CurrentEmployee = new Employee();
            }
        }

        public void SaveAccount(Employee employee)
        {
            if (employee.ID > 0)
            {
                _repo.Update(employee);
            }
            else
            {
                employee.ID = _repo.Create(employee);
            }

            EmployeeList = GetAllEmployee();
            CurrentEmployee = GetEmployee(employee.ID);
        }

        public void RemoveAccount(int id)
        {
            _repo.Delete(id);
            EmployeeList = GetAllEmployee();
            CurrentEmployee = EmployeeList.FirstOrDefault();
        }

        public List<Employee> GetAllEmployee()
        {
            return _repo.GetAllEmployee(); // Get all employee from employee repository
        }

        public Employee GetEmployee(int id)
        {
            return _repo.GetEmployeeByID(id);
        }
    }
}

