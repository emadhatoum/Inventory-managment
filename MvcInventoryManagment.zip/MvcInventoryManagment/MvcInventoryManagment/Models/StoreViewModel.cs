﻿using InventoryManagment.EF.Context;
using InventoryManagment.EF.Repositories;
using InventoryManagment.EF.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace MvcInventoryManagment.Models
{
    public class StoreViewModel
    {
        private StoreRepositories _repo;

        public List<Store> StoreList { get; set; }

        public Store CurrentStore { get; set; }

        public bool IsActionSuccess { get; set; }

        public string ActionMessage { get; set; }

        public StoreViewModel(InventoryManagmentContext context)
        {
            _repo = new StoreRepositories(context);
            StoreList = GetAllStores();
            CurrentStore = StoreList.FirstOrDefault();
        }

        public StoreViewModel(InventoryManagmentContext context, int accountId)
        {
            _repo = new StoreRepositories(context);
            StoreList = GetAllStores();

            if (accountId > 0)
            {
                CurrentStore = GetAccount(accountId);
            }
            else
            {
                CurrentStore = new Store();
            }
        }

        public void SaveAccount(Store account)
        {
            if (account.PhoneNumber > 0)
            {
                _repo.Update(account);
            }
            else
            {
                account.PhoneNumber = _repo.Create(account);
            }

            StoreList = GetAllStores();
            CurrentStore = GetAccount(account.PhoneNumber);
        }

        public void RemoveAccount(int accountID)
        {
            _repo.Delete(accountID);
            StoreList = GetAllStores();
            CurrentStore = StoreList.FirstOrDefault();
        }

        public List<Store> GetAllStores()
        {
            return _repo.GetAllStores();
        }

        public Store GetAccount(int accountId)
        {
            return _repo.GetStoreByID(accountId);
        }
    }
}
