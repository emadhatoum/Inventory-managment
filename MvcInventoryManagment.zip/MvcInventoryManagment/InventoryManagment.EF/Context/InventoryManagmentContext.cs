﻿using System;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Metadata;
using InventoryManagment.EF.Models;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace InventoryManagment.EF.Context
{
    public partial class InventoryManagmentContext : DbContext
    {
        public InventoryManagmentContext()
        {
        }

        public InventoryManagmentContext(DbContextOptions<InventoryManagmentContext> options)
            : base(options)
        {
        }

        public virtual DbSet<Brand> Brand { get; set; }
        public virtual DbSet<Customer> Customer { get; set; }
        public virtual DbSet<Employee> Employee { get; set; }
        public virtual DbSet<Image> Image { get; set; }
        public virtual DbSet<Item> Item { get; set; }
        public virtual DbSet<ItemCategory> ItemCategory { get; set; }
        public virtual DbSet<Sales> Sales { get; set; }
        public virtual DbSet<Store> Store { get; set; }
        public virtual DbSet<Vendor> Vendor { get; set; }

        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            if (!optionsBuilder.IsConfigured)
            {
#warning To protect potentially sensitive information in your connection string, you should move it out of source code. See http://go.microsoft.com/fwlink/?LinkId=723263 for guidance on storing connection strings.
                optionsBuilder.UseSqlServer("Server=localhost\\SQLEXPRESS;Database=InventoryManagment;Integrated Security=True;");
            }
        }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            modelBuilder.Entity<Brand>(entity =>
            {
                entity.Property(e => e.Name)
                    .IsRequired()
                    .HasMaxLength(50);
            });

            modelBuilder.Entity<Customer>(entity =>
            {
                entity.HasKey(e => e.CustomerId);

                entity.Property(e => e.CustomerPhoneNumber);

                entity.Property(e => e.Address)
                    .IsRequired()
                    .HasMaxLength(250);

                entity.Property(e => e.EmailAddress)
                    .IsRequired()
                    .HasMaxLength(250);

                entity.Property(e => e.Apt)
                    .IsRequired()
                    .HasMaxLength(250);

                entity.Property(e => e.City)
                   .IsRequired()
                   .HasMaxLength(250);

                entity.Property(e => e.State)
                   .IsRequired()
                   .HasMaxLength(250);

                

            });

            modelBuilder.Entity<Employee>(entity =>
            {
                entity.HasKey(e => e.ID);

                entity.Property(e => e.Address)
                    .IsRequired()
                    .HasMaxLength(250);

                entity.Property(e => e.Dob)
                    .IsRequired()
                    .HasMaxLength(15);

                entity.Property(e => e.EmailAddress).HasMaxLength(250);

                entity.Property(e => e.FirstName)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.LastName)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.MaritalStatus)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.PhoneNumber)
                    .IsRequired()
                    .HasColumnType("text");

                entity.Property(e => e.Apt)
                    .IsRequired()
                    .HasMaxLength(250);

                entity.Property(e => e.City)
                   .IsRequired()
                   .HasMaxLength(250);

                entity.Property(e => e.State)
                   .IsRequired()
                   .HasMaxLength(250);

            });

            modelBuilder.Entity<Image>(entity =>
            {
                entity.Property(e => e.Image1).HasColumnType("image");

                entity.Property(e => e.Image2).HasColumnType("image");

                entity.Property(e => e.Image3).HasColumnType("image");

                entity.Property(e => e.Image4).HasColumnType("image");
            });

            modelBuilder.Entity<Item>(entity =>
            {
                entity.HasKey(e => e.ItemId);

                entity.Property(e => e.ItemNumber);

               

                entity.Property(e => e.Brand)
                    .IsRequired()
                    .HasMaxLength(50);

               

                entity.Property(e => e.ItemCategory)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.ItemCost).HasColumnType("money");

                entity.Property(e => e.ItemDetail)
                    .IsRequired()
                    .HasMaxLength(250);

                entity.Property(e => e.PurchaseDate).HasColumnType("date");

               

                entity.Property(e => e.Unitprice).HasColumnType("money");

                entity.Property(e => e.Vendor)
                    .IsRequired()
                    .HasMaxLength(50);
            });

            modelBuilder.Entity<ItemCategory>(entity =>
            {
                entity.HasKey(e => e.CategoryId);


                entity.Property(e => e.Category)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.Description).HasMaxLength(500);

                entity.Property(e => e.StoreId).HasColumnName("StoreID");
            });

            modelBuilder.Entity<Sales>(entity =>
            {
                entity.HasKey(e => e.InvoiceNumber);

                entity.Property(e => e.ItemDetails)
                    .IsRequired()
                    .HasMaxLength(250);

                entity.Property(e => e.SalesTax).HasColumnType("money");

                entity.Property(e => e.TotalPrice).HasColumnType("money");

                entity.Property(e => e.UnitPrice).HasColumnType("money");
            });

            modelBuilder.Entity<Store>(entity =>
            {
                entity.HasKey(e => e.PhoneNumber)
                    .HasName("PK_Store_1");

                entity.Property(e => e.PhoneNumber);

                entity.Property(e => e.Address)
                    .IsRequired()
                    .HasMaxLength(250);

                entity.Property(e => e.ContactName)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.EmailAddress)
                    .IsRequired()
                    .HasMaxLength(250);

                entity.Property(e => e.StoreName)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.UserName)
                    .IsRequired()
                    .HasMaxLength(50);
            });

            modelBuilder.Entity<Vendor>(entity =>
            {


                entity.Property(e => e.PhoneNumber);
                

                entity.Property(e => e.Address)
                    .IsRequired()
                    .HasMaxLength(250);

                entity.Property(e => e.ContactName)
                    .IsRequired()
                    .HasMaxLength(50);

                entity.Property(e => e.EmailAddress)
                    .IsRequired()
                    .HasMaxLength(250);

                entity.Property(e => e.VendorId);
                   

                entity.Property(e => e.VendorName)
                    .IsRequired()
                    .HasMaxLength(50);
            });

            OnModelCreatingPartial(modelBuilder);
        }

        partial void OnModelCreatingPartial(ModelBuilder modelBuilder);
    }
}