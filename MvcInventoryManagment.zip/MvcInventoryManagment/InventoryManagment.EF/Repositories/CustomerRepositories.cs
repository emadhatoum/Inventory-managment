﻿using InventoryManagment.EF.Models;
using InventoryManagment.EF.Context;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InventoryManagment.EF.Repositories
{
    public class CustomerRepositories
    {
        private InventoryManagmentContext _dbContext;

        public CustomerRepositories(InventoryManagmentContext dbContext)
        {
            _dbContext = dbContext;
        }

        public int Create(Customer customer)
        {

            _dbContext.Add(customer);
            _dbContext.SaveChanges();

            return (int)customer.CustomerId;
        }

        public int Update(Customer customer)
        {
            Customer existingCustomer = _dbContext.Customer.Find(customer.CustomerId);
            existingCustomer.Name = customer.Name;
            existingCustomer.CustomerPhoneNumber = customer.CustomerPhoneNumber;
            existingCustomer.EmailAddress = customer.EmailAddress;

            _dbContext.SaveChanges();

            return existingCustomer.CustomerId;
        }

        public bool Delete(int PhoneNumber)
        {
            Customer customer = _dbContext.Customer.Find(PhoneNumber);
            _dbContext.Remove(customer);
            _dbContext.SaveChanges();

            return true;
        }

        public List<Customer> GetAllCustomers()
        {
            List<Customer> customersList = _dbContext.Customer.ToList();

            return customersList;
        }

        public Customer GetCustomertByID(int PhoneNumber)
        {
           Customer customer = _dbContext.Customer.Find(PhoneNumber);

            return customer;
        }
    }
}
