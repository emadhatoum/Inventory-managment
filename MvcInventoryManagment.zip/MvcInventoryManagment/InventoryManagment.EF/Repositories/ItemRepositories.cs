﻿using InventoryManagment.EF.Models;
using InventoryManagment.EF.Context;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InventoryManagment.EF.Repositories
{
    public class ItemRepositories
    {
        private InventoryManagmentContext _dbContext;

        public ItemRepositories(InventoryManagmentContext dbContext)
        {
            _dbContext = dbContext;
        }

        public int Create(Item item)
        {

            _dbContext.Add(item);
            _dbContext.SaveChanges();

            return (int)item.ItemId;
        }

        public int Update(Item item)
        {
            Item existingItem = _dbContext.Item.Find(item.ItemId);

            existingItem.ItemNumber = item.ItemNumber;
            existingItem.ItemCategory = item.ItemCategory;
            existingItem.Vendor = item.Vendor;
            existingItem.QuantityOnHand = item.QuantityOnHand;
            existingItem.Unitprice = item.Unitprice;
            existingItem.ItemCost = item.ItemCost;
            existingItem.Brand = item.Brand;
            existingItem.StoreId = item.StoreId;
            existingItem.PurchaseDate= item.PurchaseDate;
            existingItem.ItemDetail = item.ItemDetail;
            

            _dbContext.SaveChanges();

            return (int)existingItem.ItemId;
        }

        public bool Delete(int itemId)
        {
            Item item = _dbContext.Item.Find(itemId);
            _dbContext.Remove(item);
            _dbContext.SaveChanges();

            return true;
        }

        public List<Item> GetAllItems()
        {
            List<Item> itemsList = _dbContext.Item.ToList();

            return itemsList;
        }

        public Item GetItemByID(int ItemId)
        {
            Item item = _dbContext.Item.Find(ItemId);

            return item;
        }
        public Item GetItemByVendorName(string vendor)
        {
            Item item = _dbContext.Item.Find(vendor);

            return item;
        }
        public Item GetItemByItenNumber(int itemNumber)
        {
            Item item = _dbContext.Item.Find(itemNumber);

            return item;
        }
        public Item GetItemItemCategory(string category)
        {
            Item item = _dbContext.Item.Find(category);

            return item;
        }
        public Item GetItemBrand(string brand)
        {
            Item item = _dbContext.Item.Find(brand);

            return item;
           
       
        }
    }
}