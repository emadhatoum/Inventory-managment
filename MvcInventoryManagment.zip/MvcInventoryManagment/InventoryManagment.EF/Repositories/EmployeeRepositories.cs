﻿using InventoryManagment.EF.Models;
using InventoryManagment.EF.Context;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InventoryManagment.EF.Repositories
{
    public class EmployeeRepositories
    {
        private InventoryManagmentContext _dbContext;

        public EmployeeRepositories(InventoryManagmentContext dbContext)
        {
            _dbContext = dbContext;
        }

        public int Create(Employee employee)
        {

            _dbContext.Add(employee);
            _dbContext.SaveChanges();

            return (int)employee.ID;
        }

        public int Update(Employee employee)
        {
            Employee existingEmployee = _dbContext.Employee.Find(employee.ID);
            existingEmployee.ID = employee.ID;
            existingEmployee.FirstName = employee.FirstName;
            existingEmployee.LastName = employee.LastName;
            existingEmployee.PhoneNumber = employee.PhoneNumber;
            existingEmployee.EmailAddress = employee.EmailAddress;
            existingEmployee.Address = employee.Address;
            existingEmployee.Dob=employee.Dob;
            existingEmployee.Ssn=employee.Ssn;
            existingEmployee.MaritalStatus=employee.MaritalStatus;
            existingEmployee.NumberOfKids=employee.NumberOfKids;
            existingEmployee.Apt=employee.Apt;
            existingEmployee.City=employee.City;
            existingEmployee.State=employee.State;
            existingEmployee.Zip=employee.Zip;

            _dbContext.SaveChanges();

            return (int)existingEmployee.ID;
        }

        public bool Delete(int id)
        {
            Employee employee = _dbContext.Employee .Find(id);
            _dbContext.Remove(employee);
            _dbContext.SaveChanges();

            return true;
        }

        public List<Employee> GetAllEmployee()
        {
            List<Employee> employeeList = _dbContext.Employee.ToList();

            return employeeList;
        }

        public Employee GetEmployeeByID(int ID)
        {
            Employee employee = _dbContext.Employee.Find(ID);

            return employee;
        }
    }
}