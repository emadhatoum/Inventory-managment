﻿using InventoryManagment.EF.Models;
using InventoryManagment.EF.Context;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InventoryManagment.EF.Repositories
{
    public class SalesRepositories
    {
        private InventoryManagmentContext _dbContext;

        public SalesRepositories(InventoryManagmentContext dbContext)
        {
            _dbContext = dbContext;
        }

        public int Create(Sales sale)
        {

            _dbContext.Add(sale);
            _dbContext.SaveChanges();

            return (int)sale.InvoiceNumber;
        }

        public int Update(Sales sale)
        {
            Sales existingInvoice = _dbContext.Sales.Find(sale.InvoiceNumber);

            existingInvoice.InvoiceNumber = sale.InvoiceNumber;
            existingInvoice.ItemNumber=sale.ItemNumber;
            existingInvoice.ItemDetails=sale.ItemDetails;
            existingInvoice.Quantity=sale.Quantity;
            existingInvoice.UnitPrice=sale.UnitPrice;
            existingInvoice.SalesTax=sale.SalesTax;
            existingInvoice.TotalPrice=sale.TotalPrice;
            existingInvoice.CustomerPhoneNumber=sale.CustomerPhoneNumber;




            _dbContext.SaveChanges();

            return existingInvoice.InvoiceNumber;
        }

        public bool Delete(int invoiceNumber)
        {
            Sales invoice = _dbContext.Sales.Find(invoiceNumber);
            _dbContext.Remove(invoice);
            _dbContext.SaveChanges();

            return true;
        }

        public List<Sales> GetAllSales()
        {
            List<Sales> invoicesList = _dbContext. Sales.ToList();

            return invoicesList;
        }

        public Sales GetSalesByID(int contactID)
        {
            Sales sale = _dbContext.Sales.Find(contactID);

            return sale;
        }
    }
}