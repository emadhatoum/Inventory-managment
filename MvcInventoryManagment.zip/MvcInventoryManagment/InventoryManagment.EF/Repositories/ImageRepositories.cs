﻿/* using InventoryManagment.EF.Models;
using InventoryManagment.EF.Context;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InventoryManagment.EF.Repositories
{
    public class ImageRepositories
    {
        private InventoryManagmentContext _dbContext;

        public ImageRepositories(InventoryManagmentContext dbContext)
        {
            _dbContext = dbContext;
        }

        public int Create(Contacts contact)
        {
            InventoryManagmentContext
            _dbContext.Add(contact);
            _dbContext.SaveChanges();

            return contact.ContactId;
        }

        public int Update(Contacts contact)
        {
            Contacts existingContact = _dbContext.Contacts.Find(contact.ContactId);

            existingContact.FirstName = contact.FirstName;
            existingContact.LastName = contact.LastName;
            existingContact.PhoneNumber = contact.PhoneNumber;
            existingContact.EmailAddress = contact.EmailAddress;

            _dbContext.SaveChanges();

            return existingContact.ContactId;
        }

        public bool Delete(int contactID)
        {
            Contacts contact = _dbContext.Contacts.Find(contactID);
            _dbContext.Remove(contact);
            _dbContext.SaveChanges();

            return true;
        }

        public List<Contacts> GetAllContacts()
        {
            List<Contacts> contactsList = _dbContext.Contacts.ToList();

            return contactsList;
        }

        public Contacts GetContactByID(int contactID)
        {
            Contacts contact = _dbContext.Contacts.Find(contactID);

            return contact;
        }
    }
}
*/