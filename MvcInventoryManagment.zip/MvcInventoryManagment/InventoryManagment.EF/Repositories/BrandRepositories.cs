﻿using InventoryManagment.EF.Models;
using InventoryManagment.EF.Context;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;


namespace InventoryManagment.EF.Repositories
{
    public class BrandRepositories
    {
        private InventoryManagmentContext _dbContext;

        public BrandRepositories(InventoryManagmentContext dbContext)
        {
            _dbContext = dbContext;
        }

        public int Create(Brand brand)
        {

            _dbContext.Add(brand);
            _dbContext.SaveChanges();

            return (int)brand.BrandId;
        }

        public int Update(Brand brand)
        {
            Brand existinBrand = _dbContext.Brand.Find(brand.BrandId);

            existinBrand.BrandId = brand.BrandId;
            existinBrand.Name = brand.Name;

            _dbContext.SaveChanges();

            return (int)existinBrand.BrandId;
        }

        public bool Delete(int brandId)
        {
            Brand brand = _dbContext.Brand.Find(brandId);
            _dbContext.Remove(brand);
            _dbContext.SaveChanges();

            return true;
        }

        public List<Brand> GetAllBrands()
        {
            List<Brand> brandsList = _dbContext.Brand.ToList();

            return brandsList;
        }

        public Brand GetBrandByID(int brandID)
        {
            Brand brand = _dbContext.Brand.Find(brandID);

            return brand;
        }
    }
}