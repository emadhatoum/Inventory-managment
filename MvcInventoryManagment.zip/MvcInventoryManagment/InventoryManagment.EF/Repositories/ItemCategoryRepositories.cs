﻿using InventoryManagment.EF.Models;
using InventoryManagment.EF.Context;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InventoryManagment.EF.Repositories
{
    public class ItemCategoryRepositories
    {
        private InventoryManagmentContext _dbContext;

        public ItemCategoryRepositories(InventoryManagmentContext dbContext)
        {
            _dbContext = dbContext;
        }

        public int Create(ItemCategory category)
        {

            _dbContext.Add(category);
            _dbContext.SaveChanges();

            return (int)category.CategoryId;
        }

        public int Update(ItemCategory category)
        {
            ItemCategory existingCategory = _dbContext.ItemCategory.Find(category.CategoryId);

            existingCategory.Category = category.Category;
            existingCategory.Description = category.Description;
            

            _dbContext.SaveChanges();

            return existingCategory.CategoryId;
        }

        public bool Delete(int categoryId)
        {
            ItemCategory category = _dbContext.ItemCategory.Find(categoryId);
            _dbContext.Remove(category);
            _dbContext.SaveChanges();

            return true;
        }

        public List<ItemCategory> GetAllItemCategory()
        {
            List<ItemCategory> categoriesList = _dbContext.ItemCategory.ToList();

            return categoriesList;
        }

        public ItemCategory GetItemCategoryByID(int categoryId)
        {
            ItemCategory category = _dbContext.ItemCategory.Find(categoryId);

            return category;
        }
    }
}
