﻿using InventoryManagment.EF.Models;
using InventoryManagment.EF.Context;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InventoryManagment.EF.Repositories
{
    public class VendorRepositories
    {
        private InventoryManagmentContext _dbContext;

        public VendorRepositories(InventoryManagmentContext dbContext)
        {
            _dbContext = dbContext;
        }

        public int Create(Vendor vendor)
        {

            _dbContext.Add(vendor);
            _dbContext.SaveChanges();

            return vendor.VendorId;
        }

        public int Update(Vendor vendor)
        {
            Vendor existingVendor = _dbContext.Vendor.Find(vendor.VendorId);
            existingVendor.VendorName=vendor.VendorName;
            existingVendor.Address = vendor.Address;
            existingVendor.PhoneNumber = vendor.PhoneNumber;
            existingVendor.EmailAddress=vendor.EmailAddress;
            existingVendor.ContactName=vendor.ContactName;

            _dbContext.SaveChanges();

            return existingVendor.VendorId;
        }

        public bool Delete(int vendorId)
        {
            Vendor vendor = _dbContext.Vendor.Find(vendorId);
            _dbContext.Remove(vendor);
            _dbContext.SaveChanges();

            return true;
        }

        public List<Vendor> GetAllVendors()
        {
            List<Vendor> vendorsList = _dbContext.Vendor.ToList();

            return vendorsList;
        }

        public Vendor GetVendorByID(int VendorId)
        {
            Vendor vendor = _dbContext.Vendor.Find(VendorId);

            return vendor;
        }
    }
}