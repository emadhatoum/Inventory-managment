﻿using InventoryManagment.EF.Models;
using InventoryManagment.EF.Context;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace InventoryManagment.EF.Repositories
{
    public class StoreRepositories
    {
        private InventoryManagmentContext _dbContext;

        public StoreRepositories(InventoryManagmentContext dbContext)
        {
            _dbContext = dbContext;
        }

        public int Create(Store store)
        {

            _dbContext.Add(store);
            _dbContext.SaveChanges();

            return (int)store.PhoneNumber;
        }

        public int Update(Store store)
        {
            Store existingStore = _dbContext.Store.Find(store.PhoneNumber);

            
            existingStore.StoreName=store.StoreName;
            existingStore.PhoneNumber=store.PhoneNumber;
            existingStore.EmailAddress=store.EmailAddress;
            existingStore.Address=store.Address;
            existingStore.ContactName=store.ContactName;
            existingStore.UserName=store.UserName;



            _dbContext.SaveChanges();

            return existingStore.PhoneNumber;
        }

        public bool Delete(int phoneNumber)
        {
            Store store = _dbContext.Store.Find(phoneNumber);
            _dbContext.Remove(store);
            _dbContext.SaveChanges();

            return true;
        }

        public List<Store> GetAllStores()
        {
            List<Store> storesList = _dbContext.Store.ToList();

            return storesList;
        }

        public Store GetStoreByID(int phoneNumber)
        {
            Store store = _dbContext.Store.Find(phoneNumber);

            return store;
        }
    }
}
