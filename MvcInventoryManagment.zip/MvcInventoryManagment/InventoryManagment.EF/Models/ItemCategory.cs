﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace InventoryManagment.EF.Models
{
    public partial class ItemCategory
    {
        public int CategoryId { get; set; }
        public string Category { get; set; }
        public string Description { get; set; }
        public int StoreId { get; set; }
        public ItemCategory(int categoryId, string category, string description,int storeId)
        {
            CategoryId = categoryId;
            Category = category;
            Description = description;
            StoreId = storeId;
        }
        public ItemCategory()
        {

        }
    }
}
