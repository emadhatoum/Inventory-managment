﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace InventoryManagment.EF.Models
{
    public partial class Store
    {
        public string StoreName { get; set; }
        public int PhoneNumber { get; set; }
        public string EmailAddress { get; set; }
        public string Address { get; set; }
        public string ContactName { get; set; }
        public string UserName { get; set; }
        public Store(string storeName, int phoneNumber, string emailAddress, string address, string contactName, string userName)
        {
            StoreName = storeName;
            PhoneNumber = phoneNumber;
            EmailAddress = emailAddress;
            Address = address;
            ContactName = contactName;
            UserName = userName;
        }
        public Store()
        {

        }
    }
}
