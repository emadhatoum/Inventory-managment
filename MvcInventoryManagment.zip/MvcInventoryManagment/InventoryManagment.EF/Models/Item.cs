﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace InventoryManagment.EF.Models
{
    public partial class Item
    {
       public int ItemId { get; set; }
        public string ItemNumber { get; set; }
        public string ItemCategory { get; set; }
        public string Vendor { get; set; }
        public int QuantityOnHand { get; set; }
        public DateTime PurchaseDate { get; set; }
        public string Brand { get; set; }
        public string ItemDetail { get; set; }
        public decimal Unitprice { get; set; }
        public decimal ItemCost { get; set; }
       
        public int? StoreId { get; set; }
        public Item(int itemId, string itemNumber, string itemCategory, string vendor, int quantityOnHand, DateTime purchaseDate, string brand, string itemDetail, decimal unitprice, decimal itemCost, int storeId)
        {
            ItemNumber = itemNumber;
            ItemCategory = itemCategory;
            Vendor = vendor;
            QuantityOnHand = quantityOnHand;
            PurchaseDate = purchaseDate;
            Brand = brand;
            ItemDetail = itemDetail;
            Unitprice = unitprice;
            ItemCost = itemCost;
           
            StoreId = storeId;
            ItemId = itemId;
        }
        public Item()
        {

        }
    }
}
