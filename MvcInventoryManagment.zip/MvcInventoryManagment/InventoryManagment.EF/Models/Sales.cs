﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace InventoryManagment.EF.Models
{
    public partial class Sales
    {
        public int InvoiceNumber { get; set; }
        public int ItemNumber { get; set; }
        public string ItemDetails { get; set; }
        public int Quantity { get; set; }
        public decimal UnitPrice { get; set; }
        public decimal SalesTax { get; set; }
        public decimal TotalPrice { get; set; }
        public string CustomerPhoneNumber { get; set; }
        public Sales(int invoiceNumber, int itemNumber, string itemDetails, int quantity, decimal unitPrice, decimal salesTax, decimal totalPrice, string customerPhoneNumber)
        {
            InvoiceNumber = invoiceNumber;
            ItemNumber = itemNumber;
            ItemDetails = itemDetails;
            Quantity = quantity;
            UnitPrice = unitPrice;
            SalesTax = salesTax;
            TotalPrice = totalPrice;
            CustomerPhoneNumber = customerPhoneNumber;

        }
        public Sales()
        {

        }
    }
}
