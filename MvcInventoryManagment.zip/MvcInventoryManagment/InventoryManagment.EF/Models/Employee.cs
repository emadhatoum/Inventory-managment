﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace InventoryManagment.EF.Models
{
    public partial class Employee
    {
       
        public int ID { get; set; }
        public int Ssn { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public string Address { get; set; }
        public string Dob { get; set; }
        public string MaritalStatus { get; set; }
        public int? NumberOfKids { get; set; }
        public string PhoneNumber { get; set; }
        public string EmailAddress { get; set; }
        public string Apt { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public int Zip { get; set; }
        public Employee(int employeeSsn, string firstName, string lastName, string address, string dob, string maritalStatus, int? numberOfKids, string phoneNumber, string emailAddress, int iD,string apt,string city,string state,int zip)
        {
            Ssn = employeeSsn;
            FirstName = firstName;
            LastName = lastName;
            Address = address;
            Dob = dob;
            MaritalStatus = maritalStatus;
            NumberOfKids = numberOfKids;
            PhoneNumber = phoneNumber;
            EmailAddress = emailAddress;
            ID = iD;
            Apt = apt;
            City = city;
            State = state;
            Zip = zip;
        }
        public Employee()
        {

        }
    }

}
