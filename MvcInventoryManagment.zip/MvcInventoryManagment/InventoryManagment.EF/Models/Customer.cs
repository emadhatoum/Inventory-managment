﻿using System;
using System.Collections.Generic;

// Code scaffolded by EF Core assumes nullable reference types (NRTs) are not used or disabled.
// If you have enabled NRTs for your project, then un-comment the following line:
// #nullable disable

namespace InventoryManagment.EF.Models
{
    public partial class Customer
    {
        public int CustomerId { get; set; }
        public string Name { get; set; }
        public int CustomerPhoneNumber { get; set; }
        public string Address { get; set; }
        public string EmailAddress { get; set; }
        public string Apt { get; set; }
        public string City { get; set; }
        public string State { get; set; }
        public int    Zip { get; set; }
        public Customer(string name, int customerPhoneNumber, string address, string emailAddress, int customerId, string address1, string city, string state, int zip)
        {
            Name = name;
            CustomerPhoneNumber = customerPhoneNumber;
            Address = address;
            EmailAddress = emailAddress;
            CustomerId = customerId;
            Apt = address1;
            City = city;
            State = state;
            Zip = zip;
        }
        public Customer()
        {
        }
    }
    
}
